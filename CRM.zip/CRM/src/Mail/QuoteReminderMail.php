<?php

namespace Modules\CRM\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class QuoteReminderMail extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    // public $info; 

    public $sender_name;
    public $sender_email;
    public $subject;
    public $content;
    public $data;

    public $timeout = 7200; // 2 hours
    
    public function __construct($data)
    {
        $this->sender_name = $data['sender_name'];
        $this->sender_email = $data['sender_email'];
        $this->subject = $data['subject'];
        $this->content = $data['content'];
        $this->data = $data;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from($this->sender_email, $this->sender_name)->replyTo($this->sender_email, $this->sender_name)
        ->subject($this->subject)->markdown('CRM::emails.quote_reminder_mail', [
            'template' => $this->content,
            'data' => $this->data,
        ]);
    }
}
