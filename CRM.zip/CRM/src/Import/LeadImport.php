<?php
namespace Modules\CRM\Import;

use Date;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow; 
use Modules\CRM\Models\CRMLead;
use App\Models\Country;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMLeadSocialLink;

class LeadImport implements ToModel, WithHeadingRow
{

    public function __construct($source_id, $industry_id)
    {
        $this->source_id = $source_id;
        $this->industry_id = $industry_id;
    }

    public function model(array $row)
    {
 
       

        if($row['country']){
            $countries = Country::where('countries_name' ,  $row['country'])->first();
        }


        $prdopval1 = CRMLead::create([
            'source_id' => $this->source_id,
            'industry_id' =>$this->industry_id,
            'contact_name' =>  $row['name'],
            'contact_email' =>  $row['email'],
            'phone' =>  $row['phone'],
        ]);


        $leadid = $prdopval1->lead_id;

        if($row['website'] != '' || $row['address'] != '' || $row['city'] != '' || $row['state'] != '' || $row['zip'] != '' || $row['country'] != ''){

            $prdopval2 = CRMLeadContact::create([
                'lead_id' => $leadid,
                'company_name' => $row['company'],
                'contact_name' => $row['name'],
                'contact_email' => $row['email'],
                'website' => $row['website'],
                'street_address' => $row['address'],
                'city' => $row['city'],
                'state' => $row['state'],
                'zipcode' => $row['zip'],
                'countries_id' => $countries->countries_id ?? null,

            ]);
        }

        if(strtolower($row['socialmedia']) == 'whatsapp'){
            $social_type = 1;
        }elseif (strtolower($row['socialmedia']) == 'facebook') {
             $social_type = 2;
        }elseif (strtolower($row['socialmedia']) == 'instagram') {
             $social_type = 3;
        }elseif (strtolower($row['socialmedia']) == 'linkedin') {
             $social_type = 4;
        }

        if($social_type){
            $prdopval3 = CRMLeadSocialLink::create([

                    'lead_id' => $leadid,
                    'social_link'   =>   $row['sociallink'] ?? 0,
                    'social_type'   =>  $social_type ?? 0,
                ]);
        }

    }
}
