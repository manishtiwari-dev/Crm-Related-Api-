<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMQuotationItem extends Model
{
    use HasFactory;
    protected $primaryKey = 'quotation_item_id';
    protected $guarded = ['quotation_item_id'];

    public function getTable()
    {
        return config('dbtable.crm_quotation_item');
    }
    
    public $timestamps=false;
}
