<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeatureIndustry extends Model
{
    use HasFactory;
  
    // protected $connection='mysqlSuper';
    // protected $table = "sub_plan_to_feature";
   // protected $table = "website_setting";
    protected $primaryKey = 'id';
    protected $guarded = [
           'id',
    ];
    
    public function getTable()
    {
        return config('dbtable.sub_plan_feature_to_industry');
    }

    public $timestamps = false;
   
}
