<?php

namespace Modules\CRM\Models\Super;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\EnquiryProducts;
use App\Models\Country;



class SuperEnquiry extends Model
{
    use HasFactory;

    protected $primaryKey = "enquiry_id";

    public $timestamps = false;

    protected $guarded=[
     
     'enquiry_id',


    ];
     
    
    public function getTable() 
    {
        return config('dbtable.landing_web_enquiry');
    }
    

    public function country_details(){
        return $this->belongsTo(Country::class, 'countries_id', 'countries_id');
    }


  

}
