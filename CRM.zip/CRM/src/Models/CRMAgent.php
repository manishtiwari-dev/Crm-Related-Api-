<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\HRM\Models\Staff;

class CRMAgent extends Model
{
    use HasFactory;
    protected $primaryKey = 'agent_id';
    protected $guarded = [
        'agent_id',
        
    ];
    public function getTable()
    {
        return config('dbtable.crm_agent');
    }
    

     public function crm_agent(){

        return $this->hasMany(CRMAgentGroup::class,'agent_id');
    }

    public function crm_user(){

        return $this->belongsTo(Staff::class,'user_id' , 'user_id');
    }
}
