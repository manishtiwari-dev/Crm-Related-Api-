<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMSettingTaxPercentage;

class CRMSettingTaxGroup extends Model
{
    use HasFactory;
    protected $primaryKey = 'tax_group_id';
    protected $guarded = ['tax_group_id'];

    public function getTable()
    {
        return config('dbtable.crm_setting_tax_group');
    }

    public $timestamps = false;

    // public function tax_info(){
    //     return $this->belongsToMany(CRMSettingTax::class, config('dbtable.crm_setting_tax_to_tax_group'),'tax_group_id','tax_id');
    // }

    public function tax_info()
    {
        return $this->hasMany(CRMSettingTaxPercentage::class, 'tax_group_id', 'tax_group_id');
    }

    // public function tax_info()
    // {
    //     return $this->belongsToMany(CRMSettingTaxPercentage::class, config('dbtable.crm_setting_tax_type'), 'tax_group_id', 'tax_id');
    // }
}
