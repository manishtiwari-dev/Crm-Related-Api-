<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMSettingPaymentTerms extends Model
{
    use HasFactory;
    protected $primaryKey = 'terms_id';
    protected $fillable = [
        'terms_name',
        'advance_payment',
        'balance_payment',
        'status',
    ];
    public function getTable()
    {
        return config('dbtable.crm_setting_payment_terms');
    }
    
    public $timestamps=false;
}
