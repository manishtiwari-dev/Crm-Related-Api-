<?php
namespace Modules\CRM\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CRMCustomerContact extends Model
{
    use HasFactory;
    protected $primaryKey = 'contact_id';
    protected $fillable = [
        'customer_id',
        'contact_name',
        'contact_email',
        'is_default',
        'updated_at',
    ];
    public function getTable()
    {
        return config('dbtable.crm_customer_contact');
    }
    
}
