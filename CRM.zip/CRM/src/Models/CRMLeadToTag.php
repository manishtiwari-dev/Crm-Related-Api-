<?php
namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CRMLeadToTag extends Model
{
    use HasFactory;

    protected $primaryKey = "lead_id";

        public $timestamps = false;

    protected $guarded = [

        'lead_id',
    ];


    public function getTable()
    {
        return config('dbtable.crm_lead_to_tags');
    }

    public function crm_lead(){
        return $this->belongsTo(CRMLead::class,'lead_id',' lead_id');
    }
    
}
