<?php

namespace Modules\CRM\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMLeadSocialLink;
use Modules\CRM\Models\CRMLeadStatus;
use Modules\CRM\Models\CRMLeadFollowUpHistory;
use Modules\CRM\Models\CRMAgent;
use Modules\CRM\Models\CRMIndustry;
class CRMLead extends Model
{
    use HasFactory;
    protected $primaryKey = 'lead_id';
    protected $guarded = [
        'lead_id',
        
    ];
  
    public function getTable()
    {
        return config('dbtable.crm_lead');
    }

    public function crm_lead_contact()
    {
        return $this->hasMany(CRMLeadContact::class, 'lead_id', 'lead_id');
    }

    public function crm_lead_soclink()
    {
        return $this->hasMany(CRMLeadSocialLink::class, 'lead_id', 'lead_id');
    }

    public function crmleadCustomer()
    {
      return $this->belongsTo(CRMCustomer::class, 'customer_id' , 'customer_id');
    }


    public function crm_lead_source()
    {
        return $this->belongsTo(CRMLeadSource::class, 'source_id', 'source_id');
    }

    public function crm_lead_industry()
    {
        return $this->belongsTo(CRMIndustry::class, 'industry_id', 'industry_id');
    }

    public function crm_lead_agent()
    {
        return $this->belongsTo(CRMAgent::class, 'agent_id', 'agent_id');
    }

    public function crm_lead_followup()
    {
        return $this->hasOne(CRMLeadFollowUp::class, 'lead_id', 'lead_id');
    }

    public function crm_lead_followup_history()
    {
        return $this->hasMany(CRMLeadFollowUpHistory::class, 'lead_id', 'lead_id');
    }

    public function crmcustomer()
    {
      return $this->belongsTo(CRMCustomer::class, 'contact_email' , 'email');


    }

     public function crmLeadtag()
    {
        return $this->belongsToMany(CRMLeadToTag::class,  'lead_id', 'lead_id');
    }


    public function crm_social(){
        return $this->belongsTo(CRMLeadSocialLink::class,'lead_id',' lead_id');
    }

     

    public function crmLeadToTag()
    {
        return $this->belongsToMany(CRMTags::class, config('dbtable.crm_lead_to_tags'), 'lead_id', 'tags_id');
    }
   

}
