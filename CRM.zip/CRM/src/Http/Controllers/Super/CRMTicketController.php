<?php

namespace Modules\CRM\Http\Controllers\Super;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use ApiHelper;
use Modules\CRM\Models\SubCRMTickets;
use Modules\CRM\Models\SubCRMTicketsReplies;

use App\Models\UserBusiness;

use Modules\CRM\Models\Super\CRMTickets;
use Modules\CRM\Models\CRMAgent;
use Modules\CRM\Models\Super\CRMTicketsTypes;
use Modules\CRM\Models\Super\CRMTicketsReplies;

use App\Models\User;
use App\Models\Country;
use Storage;

class CRMTicketController extends Controller
{

    public $page = 'ticket';
    public $superpage = 'super-ticket';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access =  $userType == 'subscriber' ? $this->page : $this->superpage;

        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $user_id = ApiHelper::get_subscription_user_id_by_api_token($api_token);
        $userBus = ApiHelper::get_subscription_details_by_api_token($api_token);


        if ($userType == 'subscriber') {
            $data_query = SubCRMTickets::with('crm_agent_group', 'ticket_type', 'customer_list');
        } else {

            $data_query = CRMTickets::with('crm_agent_group', 'ticket_type', 'business_list');
        }


        if (!empty($data_query)) {
            if (!empty($search))
                $data_query = $data_query->where("subject", "LIKE", "%{$search}%");

            /* order by sorting */
            if (!empty($sortBY) && !empty($ASCTYPE)) {
                $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
            } else {
                $data_query = $data_query->orderBy('id', 'ASC');
            }

            $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
            $user_count = $data_query->count();




            $data_list = $data_query->skip($skip)->take($perPage)->get();
        }


        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }




    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {


            $sub_data = SubCRMTickets::where('id', $id)->first();
            $sub_data->status = $request->status;
            $sub_data->save();
        } else {


            $sub_data = CRMTickets::where('id', $id)->first();
            $sub_data->status = $request->status;
            $sub_data->save();
        }




        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access =  $userType == 'subscriber' ? $this->page : $this->superpage;

        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        if ($userType == 'subscriber') {

            $tickets = SubCRMTickets::create([
                'type_id' => $request->type_id,
                'subject' => $request->subject,

                'priority' => $request->priority,


            ]);

            $ticketsReply = SubCRMTicketsReplies::create([
                'message' => $request->message,
                'ticket_id' => $tickets->id,
                'reply_by' => 1,
            ]);
            $tickets = $ticketsReply;
        } else {


            $bus = ApiHelper::get_subscription_details_by_api_token($api_token);


            $tickets = CRMTickets::create([
                'type_id' => $request->type_id,
                'subject' => $request->subject,
                'user_id' => ApiHelper::get_subscription_user_id_by_api_token($api_token),
                'business_id' => $bus->business_id,
                'priority' => $request->priority,


            ]);

            $ticketsReply = CRMTicketsReplies::create([
                'message' => $request->message,
                'ticket_id' => $tickets->id,
                'reply_by' => 1,

            ]);
            $tickets = $ticketsReply;
        }

        if ($tickets) {
            return ApiHelper::JSON_RESPONSE(true, $tickets, 'SUCCESS_TICKETS_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TICKETS_ADD');
        }
    }
    public function create(Request $request)
    {
        $api_token = $request->api_token;

        $type_list = CRMTicketsTypes::all();

        $res = [
            'type_list' => $type_list,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function details(Request $request)
    {
        $api_token = $request->api_token;
        $userType = ApiHelper::userType($api_token);
        $page_access =  $userType == 'subscriber' ? $this->page : $this->superpage;

        if (!ApiHelper::is_page_access($api_token, $page_access, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $id = $request->id;


        if ($userType == 'subscriber') {


            $ticket_id = SubCRMTickets::find($id);
            //  $ticket_id= SubCRMTickets::with('customer_list')->where('id',$id)->first();  


            if (!empty($ticket_id->id)) {
                $data_list = SubCRMTicketsReplies::with('ticket_details', 'ticket_details.customer_list')->where('ticket_id', $ticket_id->id)->get();
            }
        } //end subscriber if

        else {

            $ticket_id = CRMTickets::find($id);


            if (!empty($ticket_id->id)) {
                $data_list = CRMTicketsReplies::with('ticket_details', 'ticket_details.business_list')->where('ticket_id', $ticket_id->id)->get();
            }
        }

        //fetch Ticket Subject name

        if ($request->has('id')) {

            if ($userType == 'subscriber') {

                $subName = SubCRMTickets::where('id', $request->id)->first();
                $sName = !empty($subName) ? $subName->subject : '';
            } else {

                $subName = CRMTickets::where('id', $request->id)->first();
                $sName = !empty($subName) ? $subName->subject : '';
            }
        }


        $res = [
            'reply_list' => $data_list,
            'subject' => $sName,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function send_reply(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;

        $userType = ApiHelper::userType($api_token);

        if ($userType == 'subscriber') {

            $ticket = SubCRMTickets::find($id);
            $data = SubCRMTicketsReplies::create([
                'ticket_id' => $ticket->id,
                'reply_by' => 1,
                'message' => $request->message,
            ]);
        } else {

            $ticket = CRMTickets::find($id);

            $data = CRMTicketsReplies::create([
                'ticket_id' => $ticket->id,
                'reply_by' => 1,
                'message' => $request->message,
            ]);
        }

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SEND_REPLY');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SEND_REPLY');
    }
}
