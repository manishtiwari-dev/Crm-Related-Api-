<?php

namespace Modules\CRM\Http\Controllers\Super;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\Enquiry;
use Illuminate\Http\Request;
use ApiHelper;
use App\Jobs\EnquiryUpdateMail;
use Modules\CRM\Models\Super\SuperEnquiry;



class EnquiryController extends Controller
{
    public $page = 'enquiry';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request){



       //Validate user page access
        $api_token = $request->api_token;
        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?$request->perPage:10;
        $search = $request->search;
        $sortBy = $request->sortBy;
        $orderBy = $request->orderBy;
       // $enquiry_type=$request->enquiry_type;

        /*Fetching subscriber data*/ 

        $enquiry_query = SuperEnquiry::with('country_details');
       //   $enquiry_query = ApiHelper::attach_query_permission_filter($enquiry_query, $api_token, $this->page, $this->pageview);

        /*Checking if search data is not empty*/
        if(!empty($search))
            $enquiry_query = $enquiry_query
                ->where("customer_name","LIKE", "%{$search}%")
                ->orWhere("customer_email","LIKE", "%{$search}%")
                ->orWhere("company_name", "LIKE", "%{$search}%")
                ->orWhere("enquiry_no","LIKE", "%{$search}%");

        /* order by sorting */
        if(!empty($sortBy) && !empty($orderBy))
            $enquiry_query = $enquiry_query->orderBy($sortBy,$orderBy);
        else
            $enquiry_query = $enquiry_query->orderBy('enquiry_id','DESC');

        /* Fetching data according enquiry type*/
 
        //if(!empty($enquiry_type))
           //$enquiry_query=$enquiry_query->where('enquiry_type', $enquiry_type);

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;

        $enquiry_count = $enquiry_query->count();

        $enquiry_list = $enquiry_query->skip($skip)->take($perPage)->get();

        $enquiry_list = $enquiry_list->map(function ($data) {
            
            $data->Country = !empty($data->country_details) 
                ? $data->country_details->countries_name 
                : "-";
            
         
            return $data;
        });

        
         /*Binding data into a variable*/
        $res = [
            'data'=>$enquiry_list,
            'current_page'=>$current_page,
            'total_records'=>$enquiry_count,
            'total_page'=>ceil((int)$enquiry_count/(int)$perPage),
            'per_page'=>$perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true,$res,'');


    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token; 
        $enquiry_id = $request->enquiry_id;
        $sub_data = SuperEnquiry::find($enquiry_id);
        $sub_data->status = $request->status;
        $sub_data->save();
        
        return ApiHelper::JSON_RESPONSE(true,$sub_data,'SUCCESS_STATUS_UPDATE');
    }
    
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $enquiry_id = $request->enquiry_id;
     
        // $data = Enquiry::UpdateOrCreate(
        //     ['lead_id' => $lead_id],
        //   [
        //       'followup_status' => $request->followup_status,
        //       'next_followup' => $request->next_followup,
              
        //   ]);

          
        //   $business_id = $subscription_data->business_id;
           $enquiry_details = SuperEnquiry::find($enquiry_id);

        $message=$request->message;
          
          if(!empty($message)){
              $details = [
                  'email' => $enquiry_details->email_address,
                  'message'=>  $message
              ];
          }
         
          EnquiryUpdateMail::dispatch($details);

        if ($details) {
            return ApiHelper::JSON_RESPONSE(true, $details, 'SUCCESS_ENQUIRY_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false,'', 'ERROR_ENQUIRY_ADD');
        }


    }



    
}
