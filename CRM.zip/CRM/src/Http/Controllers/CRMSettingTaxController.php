<?php

namespace Modules\CRM\Http\Controllers;

use ApiHelper;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\CRMSettingTaxPercentage;
use Modules\CRM\Models\CRMSettingTaxType;
use Modules\CRM\Models\CRMSettingTaxGroup;

class CRMSettingTaxController extends Controller
{

    public $page = 'tax-setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMSettingTaxGroup::with('tax_info', 'tax_info.tax_typedetails');

        if (!empty($search)) {
            $data_query = $data_query->where("tax_group_name", "LIKE", "%{$search}%");
        }

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('tax_group_id', 'ASC');
        }

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list = $data_list->map(function ($data) {
            // $taxper = $data->tax_info();
            // // $data->taxGrpname = $data->taxGroupDetails->tax_group_name ?? '';
            // //  return ApiHelper::JSON_RESPONSE(true, $taxper, '');
            // if (!empty($taxper)) {
            //     $taxper = $taxper->map(function ($sub) {
            //         $sub->tax_type_details = $sub->tax_typedetails()->first();

            //         //   $sub->menu_name = ($submenu == null) ? '' : $submenu->menu_name;

            //         return $sub;
            //     });
            // }
            // $data->componet = $taxper;


            return $data;
        });

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int) $user_count / (int) $perPage),
            'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {
    //     // Validate user page access
    //     $api_token = $request->api_token;

    //     if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
    //         return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
    //     }

    //     //validation check
    //     $rules = [
    //         'tax_name' => 'required|string',
    //         'tax_percent' => 'required',
    //         'status' => 'required',
    //     ];
    //     $validator = Validator::make($request->all(), $rules);

    //     if ($validator->fails()) {
    //         return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());
    //     }

    //     $data = $request->except(['api_token']);
    //     $prdopval = CRMSettingTax::create($data);

    //     if ($prdopval) {
    //         return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_SETTING_TAX_ADD');
    //     } else {
    //         return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SETTING_TAX_ADD');
    //     }
    // }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function edit(Request $request)
    // {
    //     $response = CRMSettingTax::find($request->tax_id);
    //     return ApiHelper::JSON_RESPONSE(true, $response, '');
    // }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    // public function update(Request $request)
    // {
    //     // Validate user page access
    //     $api_token = $request->api_token;

    //     if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
    //         return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
    //     }

    //     //validation check
    //     $rules = [
    //         'tax_name' => 'required|string',
    //         'tax_percent' => 'required',
    //         'status' => 'required',
    //     ];
    //     $validator = Validator::make($request->all(), $rules);

    //     if ($validator->fails()) {
    //         return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());
    //     }

    //     $data = $request->except(['api_token', 'terms_id']);
    //     $prdopval = CRMSettingTax::where('tax_id', $request->tax_id)
    //         ->update($data);

    //     if ($prdopval) {
    //         return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_SETTING_TAX_UPDATE');
    //     } else {
    //         return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SETTING_TAX_UPDATE');
    //     }
    // }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $tax_group_id = $request->tax_group_id;
        $sub_data = CRMSettingTaxGroup::find($tax_group_id);
        if (!empty($sub_data)) {
            $sub_data->status = $request->status;
            $sub_data->save();
        }
        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }





    public function edit(Request $request)
    {
        $tax_type_list = '';
        $tax_per = CRMSettingTaxGroup::with('tax_info', 'tax_info.tax_typedetails')->find($request->tax_group_id);

        if (!empty($tax_per)) {
            $tax_per->taxType = $tax_per->tax_info()->select('tax_type_id', 'tax_percent')->get();
            //$tax_type_list = CRMSettingTaxType::where('status', 1)->where('id', $tax_per->tax_type_id)->get();
        }

        $gName = '';
        if ($request->has('tax_group_id')) {
            //getting tax_group_name  Name
            $grpName = CRMSettingTaxGroup::where('tax_group_id', $request->tax_group_id)->first();
            $gName = !empty($grpName) ? $grpName->tax_group_name : '';
        }


        $tax_type_list    = CRMSettingTaxType::where('status', 1)->get();

        $res = [
            'tax_per' => $tax_per,
            'tax_type_list' => $tax_type_list,
            'tax_group_name' => $gName
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }




    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $taxTypedata = $request->tax_type_id ? $request->tax_type_id : 0;
        $tax_percent = $request->tax_percent ? $request->tax_percent : 0;
        $tax_grp_id = $request->tax_group_id;

        if (!empty($taxTypedata)) {
            foreach ($taxTypedata as $key => $value) {
                CRMSettingTaxPercentage::where('tax_group_id', $tax_grp_id)->delete();

                $arra = [
                    'tax_type_id'   =>  $value ?? 0,
                    'tax_percent'   =>  $tax_percent[$key] ?? 0,
                    'tax_group_id'  =>   $tax_grp_id
                ];
                $data = CRMSettingTaxPercentage::Create($arra);
            }
        }



        if ($taxTypedata) {
            return ApiHelper::JSON_RESPONSE(true, $taxTypedata, 'SUCCESS_TAX_COMPONENT_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_COMPONENT_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        //  $data = LandingPost::where('post_id', $request->post_id)->delete();
        $data = CRMSettingTaxGroup::with('tax_info')->where('tax_group_id', $request->tax_group_id)->first();
        if (!empty($data)) {

            $data->tax_info()->delete();
            $data = CRMSettingTaxGroup::where('tax_group_id', $request->tax_group_id)->delete();
        }



        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_TAX_GROUP');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_TAX_GROUP_DELETE');
        }
    }
}
