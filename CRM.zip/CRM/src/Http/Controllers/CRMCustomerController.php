<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Country;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\CRMLead;
use DateTime;


class CRMCustomerController extends Controller
{

    public $page = 'customer';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = CRMCustomer::with('crm_customer_contact','webenqcustomer','webquotecustomer','webordercustomer');


        if (!empty($search)) {
            $data_query = $data_query->where("company_name", "LIKE", "%{$search}%")
                ->orWhere("first_name", "LIKE", "%{$search}%")->orWhere("email", "LIKE", "%{$search}%");
        }

        if (empty($request->search)) {
            /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if ($request->start_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '>=', $start_date);
                }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if ($request->end_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '<=', $end_date);
                }
            }
        }

        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('customer_id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();

        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'customer_list' => $data_list,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        $leaddata = CRMLeadContact::all();
        $countrydata = Country::all();
        $res = [
            'lead' => $leaddata,
            'country' => $countrydata,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'email' => 'required|email',
                'first_name' => 'required',
            ],
            [
                'email.required' => 'SENDER_NAME_REQUIRED',
                'email.email' => 'ENTER_VALID_EMAIL',
                'first_name.required' => 'ENTER_NAME',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $mailExist = CRMCustomer::where('email', $request->email)->first();

        if (!empty($mailExist))
            return ApiHelper::JSON_RESPONSE(false, [], "E-mail already exist");


        $insert_data = $request->only(['lead_id', 'first_name', 'email', 'date_of_birth', 'contact', 'gender', 'company_name', 'website']);
        // return ApiHelper::JSON_RESPONSE(false, $insert_data, "gregrt");
        $crmCustomer = CRMCustomer::create($insert_data);
        $customer_id = $crmCustomer->customer_id;
        // return ApiHelper::JSON_RESPONSE(false,$crmCustomer->first_name,"");

        $crmcustomeraddress = CRMCustomerAddress::create([
            'customer_id' => $customer_id,
            'customer_name' => $crmCustomer->first_name,
            'customer_company' => $crmCustomer->company_name,
            'customer_email' => $crmCustomer->email,
            'address_type' => 2,
            'street_address' =>  $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
            'phone' => $request->phone,
            // 'is_default'=>$value['is_default'],
        ]);


        $data = [
            'customerdata' => $crmCustomer,
            'crmcustomeraddress' => $crmcustomeraddress,
            // 'crmcustomercontact' => $crmcustomercontact,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CUSTOMER_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_ADD');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $customer = CRMCustomer::find($request->id);
        if (!empty($customer)) {
            $customer->crm_customer_address = $customer->crm_customer_address()->select(
                'address_id',
                'address_type',
                'street_address',
                'city',
                'state',
                'zipcode',
                'countries_id',
                'phone'
            )->get();
            $customer->crm_customer_contact = $customer->crm_customer_contact()->select('contact_id', 'contact_name', 'contact_email')->get();
        }


        $lead_list = CRMLeadContact::all();
        $country_list = Country::all();
        $address = CRMCustomerAddress::all();

        $res = [
            'lead_list' => $lead_list,
            'country_list' => $country_list,
            'customer' => $customer,
            'address' => $address,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $rules = [
            'lead_id' => 'required',
            'company_name' => 'required',
            'website' => 'required|string',
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());


        $customer = CRMCustomer::where(['customer_id' => $request->customer_id])->update(
            [
                'lead_id' => $request->lead_id,
                'first_name' => $request->first_name,
                'email' => $request->email,
                'date_of_birth' => $request->date_of_birth,
                'contact' => $request->contact,
                'gender' => $request->gender,
                'company_name' => $request->company_name,
                'website' => $request->website,
                'status' => $request->status,
            ],

        );


        //  CRMCustomerAddress::where('customer_id', $request->customer_id)->delete();

        CRMCustomerAddress::updateOrCreate([
            'customer_id' =>  $request->customer_id,
        ], [
            'address_type' => 1,
            'street_address' =>  $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
            'phone' => $request->phone,

        ]);


        // $insData = [
        //     'customer_id' => $request->customer_id,
        //     'address_type' => $value['address_type'],
        //     'street_address' => $value['street_address'],
        //     'city' => $value['city'],
        //     'state' => $value['state'],
        //     'zipcode' => $value['zipcode'],
        //     'countries_id' => $value['countries_id'],
        //     'phone' => $value['phone'],
        //     //'is_default' => $value['is_default'],
        //     //'status' => $value['status'],
        // ];

        // $contact = $request->contactInfo;
        // if (!empty($contact)) {

        //     CRMCustomerContact::where('customer_id', $request->customer_id)->delete();

        //     foreach ($contact as $key => $value) {
        //         $insData = [
        //             'customer_id' => $request->customer_id,
        //             'contact_name' => $value['contact_name'],
        //             'contact_email' => $value['contact_email'],
        //             //'is_default' => $value['is_default'],
        //         ];
        //         if (!empty($value['contact_id']))
        //             CRMCustomerContact::where('contact_id', $value['contact_id'])->update($insData);
        //         else
        //             CRMCustomerContact::create($insData);
        //     }
        // }

        if ($customer)
            return ApiHelper::JSON_RESPONSE(true, $customer, 'SUCCESS_CUSTOMER_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_CUSTOMER_UPDATE');
    }

    //view

    public function view(Request $request)
    {
        $response = CRMCustomer::find($request->customer_id);
        if (!empty($response)) {
            $response->crm_customer_address = $response->crm_customer_address;
            $response->crm_customer_contact = $response->crm_customer_contact;
        }
        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    public function isdefaultupdate(Request $request)
    {
        $upid = $request->update_id;
        $type = $request->type;
        if ($type == 'address') {
            $data = CRMCustomerAddress::find($upid);

            CRMCustomerAddress::where('customer_id', $data->customer_id)->update([
                'is_default' => 0
            ]);

            $data->is_default = 1;
            $data->save();
            return ApiHelper::JSON_RESPONSE(true, ' ', 'ADDRESS-ISDEFAULT_UPDATED');
        } else {
            $contactdata = CRMCustomerContact::find($upid);
            CRMCustomerContact::where('customer_id', $contactdata->customer_id)->update([
                'is_default' => 0,
            ]);
            $contactdata->is_default = 1;
            $contactdata->save();
            return ApiHelper::JSON_RESPONSE(true, '', 'CONTACT-ISDEFAULT_UPDATED');
        }
    }

    public function changeStatus(Request $request)
    {
        $cust =  CRMCustomer::where('customer_id', $request->customer_id)->first();
        $cust->status = $cust->status == 1 ? 0 : 1;
        $cust->update();
        return ApiHelper::JSON_RESPONSE(true, $cust, 'SUCCESS_STATUS_UPDATE');
    }


    public function customerDetails(Request $request){

 

         $crmLead = CRMLead::with('crm_lead_contact')->where('lead_id' , $request->lead_id)->get();

        return ApiHelper::JSON_RESPONSE(true, $crmLead, 'SUCCESS_STATUS_UPDATE');
    }
}
