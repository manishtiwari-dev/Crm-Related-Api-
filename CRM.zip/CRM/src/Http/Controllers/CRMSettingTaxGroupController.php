<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMSettingTaxGroup;
use Modules\CRM\Models\CRMSettingTax;
use Modules\CRM\Models\CRMSettingTaxType;



class CRMSettingTaxGroupController extends Controller
{

    public $page = 'tax-setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */



    public function create()
    {

        $taxGroup = CRMSettingTaxGroup::where('status', 1)->get();

        $res = [
            'taxGroup' => $taxGroup,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit($id)
    {
        //
    }

    public function store(Request $request)
    {

        $data = new CRMSettingTaxGroup;
        $data->tax_group_name = $request->tax_group_name;
        $data->save();

        $data = CRMSettingTaxGroup::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TAX_GROUP_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_ADD');
        }
    }

    public function update(Request $request)
    {
        $data = CRMSettingTaxGroup::findOrFail($request->tax_group_id);
        $data->tax_group_name = $request->tax_group_name;
        $data->save();

        $data = CRMSettingTaxGroup::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_TAX_GROUP_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_TAX_GROUP_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        // CRMSettingTaxGroup::destroy($request->tax_group_id);

        $infoData =  CRMSettingTaxGroup::findOrFail($request->tax_group_id);
        if (!empty($infoData)) {
            $infoData->tax_group_name =  $infoData->tax_group_name;
            $infoData->status = 0;
            $infoData->save();
        }

        $data = CRMSettingTaxGroup::all();

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_DELETE_JOB_TYPE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_JOB_TYPE_DELETE');
        }
    }
}
