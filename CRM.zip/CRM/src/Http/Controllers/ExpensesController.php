<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Modules\CRM\Models\CRMExpenses;
use Modules\CRM\Models\CRMExpensesCategories;
use ApiHelper;

class ExpensesController extends Controller
{

    public $page = 'agent';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {


       $crmexpanselist =  CRMExpenses::with('expanse_category')->get();


       $res = [
            'crmexpanselist' => $crmexpanselist,
       ];
        
        return ApiHelper::JSON_RESPONSE(true, $res , '');
    }

    public function create(Request $request)
    {
       $crm_expense_category = CRMExpensesCategories::all();

       $res = [
        "crm_expense_category" => $crm_expense_category
       ];
       
      return ApiHelper::JSON_RESPONSE(true, $res , '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
     
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

    

        $crmexpensecategory = CRMExpenses::create([
            'expense_name' => $request->name,
            'category' => $request->category,
            'currency' => $request->currency,
            'amount' => $request->amount,
            'note' => $request->note,
            'tax_id' => $request->tax1,
            'paymentmode' => $request->payment_mode,
            'invoiceid' => '5', 
        ]);

         

        return ApiHelper::JSON_RESPONSE(true, $crmexpensecategory, 'SUCCESS_EXPENSE_ADD');   
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $expense = CRMExpenses::find($request->expense_id);

        $res = [ 
          'expenses' => $expense,  
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');  
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        
    }

    public function destroy(Request $request)
    {
        CRMExpenses::where('id' , $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_EXPENSE');  
    }


}
