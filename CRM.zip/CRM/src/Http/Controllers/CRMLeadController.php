<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use ApiHelper;
use Modules\CRM\Models\CRMIndustry;
use Modules\CRM\Models\CRMLeadSource;
use Modules\CRM\Models\CRMLeadStatus;
use App\Models\Country;
use Modules\CRM\Models\CRMAgent;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMLeadFollowUp;
use Modules\CRM\Models\CRMLeadFollowUpHistory;
use Modules\CRM\Models\CRMLeadSocialLink;
use Storage;

class CRMLeadController extends Controller
{

    public $page = 'lead';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        // $data_query = CRMLead::with('crm_lead_followup','crm_lead_followup.crmLeadStatus');
        // attaching query filter by permission(all, added,owned,both)
        //$data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);


        // if (!empty($search))
        //     $data_query = $data_query->where("phone", "LIKE", "%{$search}%");

        // /* order by sorting */
        // if (!empty($sortBY) && !empty($ASCTYPE)) {
        //     $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        // } else {
        //     $data_query = $data_query->orderBy('lead_id', 'ASC');
        // }

        // $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        // $user_count = $data_query->count();

        // $data_list = $data_query->skip($skip)->take($perPage)->get();

        // $data_list = $data_list->map(function ($data) {

        //     $data->folloup_date = !empty($data->crm_lead_followup)
        //         ? date("Y-m-d", strtotime($data->crm_lead_followup->next_followup))
        //         : "-";

        //     $status_id = !empty($data->crm_lead_followup) ? $data->crm_lead_followup->followup_status : 0;
        //     // $data=$status_id;

        //     $status_data = CRMLeadStatus::find($status_id);
        //     if (!empty($status_data->status_name)) {
        //         $data->statusName =  $status_data->status_name;
        //     }
        //     $data->status = $status_id;


        //     $data->total = CRMLeadFollowUp::where('followup_status', $status_id)->count();


        //     $status_data = CRMIndustry::find($data->industry_id);
        //     $data->industry_id = !empty($status_data) ? $status_data->industry_name : "";

        //     $data->priority = ($data->priority == 1) ? "Low" : (($data->priority == 2) ? "Medium" : "High");

        //     $data->folllow_up = ($data->folllow_up == 1) ? "Yes" : "No";


        //     return $data;
        // });
        // $leadstatus = CRMLeadStatus::where('status' , 1)->get();

        $data = CRMLeadFollowUp::with('crmLeadStatus','crm_lead','enquiry','quotation','order')->orderBy('followup_id', 'DESC');

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data->count();
        $data_list = $data->skip($skip)->take($perPage)->get();

        $res = [
            'lead_list' => $data_list,
            // 'leadstatus' => $leadstatus,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
         
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {


       

    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
       
    }

    //view


    public function view(Request $request)
    {
        $response = CRMLead::with('crm_lead_followup_history')->find($request->lead_id);

        $followupresponse = CRMLeadFollowUp::find($request->lead_id);

        
        if (!empty($response)) {
            $response->crm_lead_contact = $response->crm_lead_contact;
            $response->crm_lead_soclink = $response->crm_lead_soclink;
            $response->crm_lead_source = $response->crm_lead_source;
            $response->crm_lead_industry = $response->crm_lead_industry;
            $response->crm_lead_agent = $response->crm_lead_agent;
            $response->crm_lead_source = $response->crm_lead_source;
            // if(!empty($response->crm_lead_followup->crm_lead_followup_history))

            $response->crm_lead_followup_history = $response->crm_lead_followup_history;
            // if(!empty( $followup))

            $response->crm_lead_followup = $response->crm_lead_followup;
            $response->crm_lead_status = CRMLeadStatus::all();


        }

        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }


    //lead_followup_store

    public function lead_followup_store(Request $request)
    {
        $lead_id = 0;

        if ($request->followup_status || $request->next_followup) {

            $lead_id = $request->lead_id;


            $data = CRMLeadFollowUp::UpdateOrCreate(
                ['lead_id' => $lead_id],
                [
                    'followup_status' => $request->followup_status,
                    'next_followup' => $request->next_followup,

                ]
            );




            $histdata = CRMLeadFollowUpHistory::create([
                'followup_note' => $request->followup_note,

                'lead_id' => $lead_id,
            ]);
        }



        $response = [
            'followupdata' => $data,
            'followuphistorydata' => $histdata,
        ];

        if ($response) {
            return ApiHelper::JSON_RESPONSE(true, $response, 'SUCCESS_LEAD_FOLLOW_UP_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_LEAD_FOLLOW_UP_UPDATE');
        }

        // return ApiHelper::JSON_RESPONSE(true, $response, '');
    }



    public function status_tab()
    {
        $list = CRMLeadStatus::all();
        if (!empty($list)) {
            $list = $list->map(function ($data) {
                $data->total = CRMLeadFollowUp::where('followup_status', $data->status_id)->count();
                return $data;
            });
        }


        $response = [
            'list' => $list,

        ];


        return ApiHelper::JSON_RESPONSE(true, $response, '');
    }

    public function import_file(Request $request)
    {

        $dataList = ApiHelper::read_csv_data($request->fileInfo, "csv/lead");

        foreach ($dataList as $key => $value) {

            $indsID = '';
            $leadsID = '';
            $custcontID = '';
            $industryid = $value[0];
            $leadarrid = $value[3];

            $custnameid = $value[1];
            $custemailid = $value[2];

            $insdata =  CRMIndustry::where('industry_name', $industryid)->first();



            if (!empty($insdata))
                $indsID = $insdata->industry_id;
            else {
                $data = ['industry_name' => $industryid];
                $prdopval = CRMIndustry::create($data);
                $indsID = $prdopval->industry_id;
            }

            $leaddata =  CRMLead::where('company_name', $leadarrid)->first();

            if (!empty($leaddata))
                $leadsID = $leaddata->lead_id;
            else {
                $data = [
                    'company_name' => $value[3],
                    'phone' => $value[4],
                    'website' => $value[5],
                    'address' => $value[6],
                    'city' => $value[7],
                    'state' => $value[8],
                    'zipcode' => $value[9],
                    'country' => $value[10],
                    'industry_id' => $indsID,
                    'source_id' => !empty($request->source_id) ? $request->source_id : 1,
                    'status_id' => 7,
                ];
                $prdopval = CRMLead::create($data);
                $leadsID = $prdopval->lead_id;
            }

            $ContactData = ['contact_name' => $value[1], 'contact_email' => $value[2], 'lead_id' => $leadsID];
            $insdata =  CRMLeadContact::where($ContactData)->first();
            // return ApiHelper::JSON_RESPONSE(true, $ContactData, 'DATA_INSERTED');
            if (empty($insdata))
                CRMLeadContact::create($ContactData);
        }

        return ApiHelper::JSON_RESPONSE(true, $dataList, 'SUCCESS_CRM_LEAD_IMPORTED');
    }




    public function changeStatus(Request $request)
    {


        $quoteId = $request->quoteId;
        $statusId = $request->statusId;


        $quote = CRMLeadFollowUp::where('lead_id', $quoteId)->first();
        if (!empty($quote->followup_status))
            $quote->followup_status = $statusId;
        $quote->save();

        if ($quote)
            return ApiHelper::JSON_RESPONSE(true, $quote, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
    }


    public function destroy(Request $request)
    {
       
    }
}
