<?php

namespace Modules\CRM\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\CRM\Models\CRMExpensesCategories;
use Illuminate\Support\Facades\Validator; 
use ApiHelper;

class SettingController extends Controller
{

    public $page = 'agent';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        $crmexpansecategory = CRMExpensesCategories::all();
        $res = [
            'crmexpansecategory' => $crmexpansecategory
        ];
        return ApiHelper::JSON_RESPONSE(true, $res , '');
    }

    public function create(Request $request)
    {
      return ApiHelper::JSON_RESPONSE(true, [], '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
 
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

    

        $crmexpensecategory = CRMExpensesCategories::create([
            'name' => $request->expense_name,
            'description' => $request->expense_category
        ]);

         

        return ApiHelper::JSON_RESPONSE(true, $crmexpensecategory, 'SUCCESS_EXPENSE_ADD');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       
   
        $api_token = $request->api_token;
        $expense = CRMExpensesCategories::find($request->expense_id);


         $response = [
           'expense'=>$expense,
          
            ];


      
  
       return ApiHelper::JSON_RESPONSE(true, $response,'');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
         $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        
        

       $expense_category = CRMExpensesCategories::find($request->id);
       $expense_category->name = $request->expense_name;
       $expense_category->description = $request->editexpense_description;
       $expense_category->update();


        if ($expense_category) {
            return ApiHelper::JSON_RESPONSE(true, $expense_category, 'SUCCESS_SETTING_CATEGORY_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SOURCE_UPDATE');
        }
    }

    public function destroy(Request $request)
    {   

        CRMExpensesCategories::where('id' , $request->id)->delete();

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_DELETE_EXPENSE_CATEGORY');  
    }


}
