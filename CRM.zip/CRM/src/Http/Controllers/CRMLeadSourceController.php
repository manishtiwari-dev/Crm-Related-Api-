<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use Modules\CRM\Models\CRMIndustry;
use Modules\CRM\Models\CRMLeadSource;
use Modules\CRM\Models\CRMLeadStatus;
use Modules\CRM\Models\CRMAgent;
use Modules\CRM\Models\CRMTags;
use Modules\HRM\Models\Department;
use Modules\HRM\Models\Staff;

class CRMLeadSourceController extends Controller
{

    public $page = 'lead_setting';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
  
           $source_list = CRMLeadSource::orderBy('source_id','asc')->paginate(10);
           $industry_list = CRMIndustry::orderBy('created_at','DESC')->paginate(10);
           $status_list = CRMLeadStatus::orderBy('sort_order','asc')->paginate(10);
           $agent_list = CRMAgent::with('crm_user')->orderBy('created_at','DESC')->paginate(10);
           $dept_list = Department::all();
           $tag_list = CRMTags::orderBy('created_at','DESC')->paginate(10);

        $res = [
            'source_list' => $source_list,
            'industry_list' => $industry_list,
            'status_list' => $status_list,
            'agent_list' => $agent_list,
            'dept_list' => $dept_list,
            'tag_list' => $tag_list,
              
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'source_name' => 'required|string',
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());

        $data = $request->only(['source_name']);

        $crmleadsource = CRMLeadSource::where('source_name' , $data)->first();

        if(!empty($crmleadsource)){
            return ApiHelper::JSON_RESPONSE(false, '', 'Source Name Already Exist');
        }else{
            $prdopval = CRMLeadSource::create($data);
        }

        return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_SOURCE_ADD');

        // if ($prdopval) {
        //     return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_SOURCE_ADD');
        // } else {
        //     return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SOURCE_ADD');
        // }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {

        $api_token = $request->api_token;
        $source = CRMLeadSource::find($request->source_id);


         $response = [
           'source'=>$source,
          
            ];


      
  
       return ApiHelper::JSON_RESPONSE(true, $response,'');
    


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');

        //validation check 
        $rules = [
            'source_name' => 'required|string',
           
        ];
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, '', $validator->messages());
         $data = $request->only(['source_name']);
    //    $data = $request->except(['api_token', 'source_id']);
        $prdopval = CRMLeadSource::where('source_id', $request->source_id)
            ->update($data);


        if ($prdopval) {
            return ApiHelper::JSON_RESPONSE(true, $prdopval, 'SUCCESS_SOURCE_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_SOURCE_UPDATE');
        }
    }


    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;

       $source =  CRMLeadSource::where('source_id' ,$request->source_id)->first();
       $source->status = $request->status;
       $source->update();
       return ApiHelper::JSON_RESPONSE(true, $source, 'SUCCESS_STATUS_UPDATE');

    }

    public function sortOrder(Request $request){


        $crmLeadStatus = CRMLeadStatus::where('status_id', $request->status_id)->first();
         
        if (!empty($crmLeadStatus)) {
            $crmLeadStatus->sort_order = $request->sort_order;
            $crmLeadStatus->update();

            return ApiHelper::JSON_RESPONSE(true, $crmLeadStatus, 'SUCCESS_SORT_ORDER_CHANGE');
        }

       
    }

    public function statusColor(Request $request){
        $crmLeadStatus = CRMLeadStatus::where('status_id', $request->color_id)->first();
         
        if (!empty($crmLeadStatus)) {
            $crmLeadStatus->status_color = $request->status_color;
            $crmLeadStatus->update();

            return ApiHelper::JSON_RESPONSE(true, $crmLeadStatus, 'SUCCESS_STATUS_COLOR_CHANGE');
        }
    }


}
