<?php

namespace Modules\CRM\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
use App\Models\Country;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMCustomerAddress;
use Modules\CRM\Models\CRMCustomerContact;
use Modules\CRM\Models\Enquiry;
use Modules\Ecommerce\Models\Order;
use Modules\CRM\Models\CRMQuotation;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadFollowUp;
use Modules\CRM\Models\CRMLeadStatus;
use Modules\CRM\Models\CRMLeadFollowUpHistory;
use Modules\CRM\Models\CRMLeadNotes;
use Modules\CRM\Models\CRMIndustry;
use Modules\CRM\Models\CRMLeadSource;
use Modules\CRM\Models\CRMAgent;    
use Modules\CRM\Models\CRMLeadSocialLink;
use Modules\CRM\Models\CRMTags;
use Modules\CRM\Models\CRMLeadToTag;
use Maatwebsite\Excel\Facades\Excel;
use Modules\CRM\Import\LeadImport;
use Storage;
use App\Models\User;
use DateTime;
use DB;


class CRMLeadsControllers extends Controller
{

    public $page = 'Clients';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public static function enquiryCount($id){

        $enqcount = Enquiry::where('customer_id' , $id)->count();

        return $enqcount;
    }

    public function index(Request $request)
    {

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10; 
        $sortBY = $request->sortBy;
        $search = $request->search;
        $ASCTYPE = $request->orderBY;



        $crm_customer = config('dbtable.crm_customer');
        $web_orders = config('dbtable.web_orders'); 
        $web_enquiry = config('dbtable.web_enquiry'); 

        $data_query = CRMLead::with('crmcustomer','crm_lead_agent','crm_lead_industry','crmLeadToTag')->orderBy('lead_id', 'DESC');

        if (!empty($request->search)) {
            $data_query = $data_query->where("contact_name", 'Like','%'.$search.'%')
                ->orWhere("contact_email",'Like','%'.$search.'%');
        }

        if (empty($request->search)) {
            /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if ($request->start_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '>=', $start_date);
                }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if ($request->end_date != NULL) {
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    $data_query = $data_query->whereDate('created_at', '<=', $end_date);
                }
            }

            if ($request->has('category')) {
                if ($request->category != NULL) {
                    $data_query = $data_query->where("industry_id",  $request->category);
                }
            }

            if ($request->has('agent_id')) {
                if ($request->agent_id != NULL) {
                    $data_query = $data_query->where("agent_id",  $request->agent_id);
                }
            }
 

            if ($request->has('tag_select')) {
                if(!empty($request->tag_select)){
                 $tag_select = $request->tag_select;
                
                $data_query =  $data_query->orWhereHas('crmLeadToTag',function ($query)use($tag_select)
                  {
                      $query->whereIn('crm_lead_to_tags.tags_id', $tag_select);
                  });
            }
            }
        }


        $crmagentlist = CRMAgent::orderBy('agent_id', 'DESC')->get();
        $crmindustrylist = CRMIndustry::orderBy('industry_id', 'DESC')->get(); 
        $crmtags = CRMTags::where('status' , 1)->get();
        $crmLeadTags = CRMLeadToTag::all();

        
        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $user_count = $data_query->count();
        $crmleadlists = $data_query->skip($skip)->take($perPage)->get();

        // foreach ($crmleadlists as $key => $crmlead) {
        //     $lead_tags = explode(',', $crmlead->tags);
        //     $crm_taglist = [];
        //     foreach ($lead_tags as $key => $lead) {
        //         $crmtag = CRMTags::where('tags_id' , $lead)->first();
        //         array_push($crm_taglist, $crmtag);
        //     }

        //      $crm_list = [
        //         'lead_id' => $crmlead->lead_id,
        //         'agent_id' => $crmlead->agent_id,
        //         'contact_name' => $crmlead->contact_name,
        //         'contact_email' => $crmlead->contact_email,
        //         'orderCount' => Order::orderCount($crmlead->crmcustomer->customer_id ?? null),
        //         'enquiryCount' => Enquiry::enquiryCount($crmlead->crmcustomer->customer_id ?? null),
        //         'Quotation' => CRMQuotation::quotationCount($crmlead->crmcustomer->customer_id ?? null),
        //         'status' => $crmlead->status,
        //         'agent_details' =>CRMLead::with('crmcustomer','crm_lead_agent','crm_lead_industry')->where('lead_id' , $crmlead->lead_id)->first(),
        //         'lead_tags' => $crm_taglist, 

        //      ];

        //      array_push($data, $crm_list);
        // }

        

        $res = [ 
            'crmleadlist' => $crmleadlists,
            'current_page' => $current_page,
            'total_records' => $user_count,
            'total_page' => ceil((int)$user_count / (int)$perPage),
            'per_page' => $perPage,
            'crmagentlist' => $crmagentlist,
            'crmindustrylist' => $crmindustrylist,
            'start_date' =>$request->start_date,
            'end_date' => $request->end_date,
            'crmtags' => $crmtags,
            'crmLeadTags'=>$crmLeadTags
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create() {
        $industrydata = CRMIndustry::where('status' , 1)->get();
        $leadsource = CRMLeadSource::where('status' , 1)->get();
        $leadstatus = CRMLeadStatus::where('status' , 1)->get();
        $countrydata = Country::all();
        $crmagentdata = CRMAgent::where('status' , 1)->get();
        $crmtags = CRMTags::where('status' , 1)->get();

        $res = [
            'industrydata' => $industrydata,
            'leadsource' => $leadsource,
            'leadstatus' => $leadstatus,
            'countrydata' => $countrydata,
            'crmagentdata' => $crmagentdata,
            'crmtags' =>$crmtags
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
 
        $requestData = $request->only(['source_id',  'contact_name', 'contact_email', 'phone', 'industry_id']);

        $crm_lead = CRMLead::where('contact_email', $request->contact_email)->first();

        if (empty($crm_lead)) {
            $prdopval1 = CRMLead::create($requestData);
            $leadid = $prdopval1->lead_id;
        }else{
            return ApiHelper::JSON_RESPONSE(false, [], 'CONTACT_EMAIL_ALREADY_EXIST');
        }


            $LeadToTag = [];
            if(!empty($request->tags)){
                foreach ($request->tags as $key => $tag_id) {
                    $LeadToTag[$key]['lead_id'] = $leadid;
                    $LeadToTag[$key]['tags_id'] = $tag_id;
                }
            }

            $prdopval1->crmLeadToTag()->attach($request->tags);

        


        if(   $request->website != ''  || $request->street_address != '' || $request->city != '' || $request->state != '' ||  $request->zipcode != ''|| $request->countries_id != ''){
            $crm_lead_contact = CRMLeadContact::create([
                'lead_id' => $leadid,
                'company_name' => $request->company_name,
                'contact_name' => $request->contact_name,
                'contact_email' => $request->contact_email,
                'website' => $request->website,
                'street_address' => $request->street_address,
                'city' => $request->city,
                'state' => $request->state,
                'zipcode' => $request->zipcode,
                'countries_id' => $request->countries_id,

            ]);
        }


        $socialLinkdata = $request->social_link ? $request->social_link : 0;
        $socialType = $request->social_type ? $request->social_type : 0;

        foreach ($socialLinkdata as $key => $value) {
            if(!empty($value) || !empty($socialType[$key])){
                $prdopval3 = CRMLeadSocialLink::create([

                    'lead_id' => $leadid,
                    'social_link'   =>  $value ?? 0,
                    'social_type'   =>  $socialType[$key] ?? 0,
                ]);
            }
        }

        $data = [
            'leaddata' => $prdopval1,
            'leadcontactdata' => $crm_lead_contact ?? '',
            'sociallinkdata' => $prdopval3 ?? '',
            // 'followupdata'=>$followupdata,
            'followupdata' => [],
        ];

        /* generayte lead notifification */
        // $msag = 'Lead Of this ' . $crm_lead_contact->company_name . ' Created successfully !';
        // $title = 'Lead';
        // ApiHelper::realtimeNoti([
        //     'user_id' => ApiHelper::get_adminid_from_token($api_token),
        //     'type' => 1,
        //     'msg' => $msag,
        //     'title' => $title,
        //     // 'pusherDId' => $request->pusherDId,
        // ]);  // generate notifiction

        if ($data) {
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_LEAD_ADD');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_LEAD_ADD');
        }
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
         $lead          = CRMLead::with('crmLeadToTag')->find($request->lead_id);

        if (!empty($lead)) {
            $lead->contact = $lead->crm_lead_contact()->select('contact_name', 'contact_email')->get();
            $lead->socialLink = $lead->crm_lead_soclink()->select('social_type', 'social_link')->get();
            $lead->crm_lead_followup = $lead->crm_lead_followup;
            $lead->crm_lead_contact = $lead->crm_lead_contact;


            if (!empty($lead->crm_lead_contact->countries_id))
                $lead->selectedCountry = Country::whereRaw('countries_id IN(' . $lead->crm_lead_contact->countries_id . ') ')->get();
        }






        $leadSource    = CRMLeadSource::where('status', 1)->get();
        $industry      = CRMIndustry::where('status', 1)->get();
        $country       = Country::where('status', 1)->get();
        $socialLink    = CRMLeadSocialLink::where('lead_id', $lead->lead_id)->get() ?? '';
        $leadstatus = CRMLeadStatus::all();
        $crmtags = CRMTags::where('status' , 1)->get();
        $crmLeadtoTag = CRMLeadToTag::where('lead_id' , $request->lead_id)->get();

        $res = [
            'lead' => $lead,
            'industry' => $industry,
            'leadSource' => $leadSource,
            'leadstatus' => $leadstatus,
            'country' => $country,
            'socialLink' => $socialLink,
            'crmtags' => $crmtags,
            'crmLeadtoTag' => $crmLeadtoTag
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;


        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
     
        $data = $request->only(['source_id',  'contact_name', 'contact_email', 'phone', 'industry_id']);
        //  $data = $request->except(['api_token', 'lead_id', 'socialLink','followup_id','followup_status','next_followup']);
        $crm_leads = CRMLead::where('lead_id', $request->lead_id)->update($data);

        $leadid = $request->lead_id;


        $arra = [
            'lead_id' => $leadid,
            'company_name' => $request->company_name,
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'website' => $request->website,
            'street_address' => $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
        ];

       
           
            $postTag = CRMLead::find($request->lead_id);
            $postTag->crmLeadToTag()->detach();

            // attach category to post
            if (!empty($request->tags)) {
                // for post to category
                $LeadToTag = [];
                foreach ($request->tags as $key => $tag_id) {
                    $LeadToTag[$key]['lead_id'] = $postTag->lead_id;
                    $LeadToTag[$key]['tags_id'] = $tag_id;
                }
                $postTag->crmLeadToTag()->attach($LeadToTag);
            }


    if(   $request->website != ''  || $request->street_address != '' || $request->city != '' || $request->state != '' ||  $request->zipcode != ''|| $request->countries_id != ''){
        $crm_lead_contact = CRMLeadContact::updateOrCreate([
            'lead_id' => $leadid,
        ],
        [
            'lead_id' => $leadid,
            'company_name' => $request->company_name,
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'website' => $request->website,
            'street_address' => $request->street_address,
            'city' => $request->city,
            'state' => $request->state,
            'zipcode' => $request->zipcode,
            'countries_id' => $request->countries_id,
        ]
        );
    }

        $socialLinkdata = $request->social_link ? $request->social_link : 0;
        $social_type = $request->social_type ? $request->social_type : 0;


        if (!empty($socialLinkdata)) {
            CRMLeadSocialLink::where('lead_id', $leadid)->delete();
            foreach ($socialLinkdata as $key => $value) {
                if(!empty($value) || !empty($socialType[$key])){
                $arra = [
                    'lead_id' => $leadid,
                    'social_link'   =>  $value ?? 0,
                    'social_type'   =>  $social_type[$key] ?? 0,
                ];
                $prdopval3 = CRMLeadSocialLink::Create($arra, $arra);
            }
            }
        }

   
        if ($crm_leads) {
            return ApiHelper::JSON_RESPONSE(true, $crm_leads, 'SUCCESS_LEAD_UPDATE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_LEAD_UPDATE');
        }
    }

    public function show(Request $request){

        $crmlead= CRMLead::with('crmcustomer','crm_lead_agent','crm_lead_industry','crm_lead_contact','crmLeadToTag')->where('lead_id' , $request->id)->first();

        $crmLeadfollowup = CRMLeadFollowUp::with('crmLeadStatus','crm_lead_followup_history','crm_lead_followup_history.crmLeadStatus','User','enquiry','order','quotation')->where('lead_id' , $request->id)->orderBy('followup_id', 'DESC')->get();

        $crmleadnotelist = CRMLeadNotes::where('lead_id' , $request->id)->orderBy('note_id', 'DESC')->get();

        $crm_tags = CRMTags::orderBy('tags_id', 'DESC')->where('status',1)->get();
 
        $tag_arr = explode(',', $crmlead->tags);


        if(!empty($crmlead->crmcustomer->customer_id)){
            $ordertDetails = Order::with('followupstatus' , 'followupstatus.crmLeadStatus')->where('customer_id' , $crmlead->crmcustomer->customer_id)->orderBy('order_id', 'DESC')->get();
            $enquiryDetails = Enquiry::with('followupstatus' , 'followupstatus.crmLeadStatus')->where('customer_id' , $crmlead->crmcustomer->customer_id)->orderBy('enquiry_id', 'DESC')->get();
            $quotationDetails = CRMQuotation::with('followupstatus','followupstatus.crmLeadStatus')->where('customer_id' , $crmlead->crmcustomer->customer_id)->orderBy('quotation_id', 'DESC')->get();
        }else{
            $ordertDetails = '';
            $enquiryDetails = '';
            $quotationDetails = '';
        }
  
             $crm_list = [
                'lead_id' => $crmlead->lead_id,
                'contact_name' => $crmlead->contact_name,
                'contact_email' => $crmlead->contact_email,
                'phone' => $crmlead->phone,
                'street_address' => $crmlead->crm_lead_contact[0]->street_address ?? '',
                'city' => $crmlead->crm_lead_contact[0]->city ?? '',
                'state' => $crmlead->crm_lead_contact[0]->state ?? '',
                'zipcode' => $crmlead->crm_lead_contact[0]->zipcode ?? '',
                'agent_name' => $crmlead->crm_lead_agent->agent_name ?? '',
                'category' => $crmlead->crm_lead_industry->industry_name ?? '',
                'orderCount' => Order::orderCount($crmlead->crmcustomer->customer_id ?? null),
                'ordertDetails' => $ordertDetails,
                'enquiryCount' => Enquiry::enquiryCount($crmlead->crmcustomer->customer_id ?? null),
                'enquiryDetails' => $enquiryDetails,
                'Quotation' => CRMQuotation::quotationCount($crmlead->crmcustomer->customer_id ?? null),
                'quotationDetails' => $quotationDetails,
                'status' => $crmlead->status,
                'crmLeadfollowup' => $crmLeadfollowup,
                'leadstatuslist' => CRMLeadStatus::where('status' , 1)->get(),
                'crmleadnotelist' => $crmleadnotelist,
                'crm_tags' => $crm_tags,
                'tag_arr' => $tag_arr,
                'crmlead' => $crmlead
             ];

            


         $res = [ 
            'crm_list' => $crm_list
            ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function destroy(Request $request){

    
        $id = $request->id;
        if (CRMLead::find($id)->exists()) {
            $leadContact    = CRMLeadContact::where('lead_id', $id)->delete();
            $socialLink = CRMLeadSocialLink::where('lead_id', $id)->delete();
            $lead       = CRMLead::find($id)->delete();
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_LEAD_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ALLREADY_LEAD_DELETE');
        }
    }

    public function changeStatus(Request $request){

        $lead_id = $request->lead_id;
        $status = $request->status;

        $changeStatus = CRMLead::where('lead_id', $lead_id)->first();


        $changeStatus->status = $status;
        $changeStatus->save();

        if ($changeStatus)
            return ApiHelper::JSON_RESPONSE(true, $changeStatus, 'SUCCESS_STATUS_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_STATUS_UPDATE');
    }


    public function agentsUpdate(Request $request){

       
       

        $agent = CRMLead::where('lead_id', $request->lead_id)->update(
            [                
                'agent_id' => $request->agent_id,
            ]
        );


        if ($agent)
            return ApiHelper::JSON_RESPONSE(true, $agent, 'SUCCESS_AGENT_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, '', 'ERROR_AGENT_UPDATE');
    }


    public function leadImportCreate(Request $request){

        $industrydata = CRMIndustry::all();
        $leadsource = CRMLeadSource::all();

         $res = [
            'industrydata' => $industrydata,
            'leadsource' => $leadsource,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function leadImportStore(Request $request){

        $import_file = $request->file('import_file');

        if (!empty($import_file)) {


            Excel::import(new LeadImport($request->source_id, $request->industry_id),  $request->file('import_file'));


            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_LEAD_IMPORT');

        }

    }
   

    
}
